# Turning Food Reviews into Structured Insight with an LLM

Classify unstructured customer reviews into sentiment and topics using an LLM API, then
**measure** how accurate it is against ground truth and against a classical ML baseline.

> Status: TODO. Fill in the results sections below only after you have run the project.

## Problem
Companies receive large volumes of free-text customer feedback. This project extracts
structured fields (sentiment, topics, complaint summary) from reviews and evaluates
whether an LLM is actually better than a simple TF-IDF + logistic regression model.

## Data
[Amazon Fine Food Reviews](https://www.kaggle.com/snap/amazon-fine-food-reviews) (Kaggle, ~568K reviews, 1999-2012).
Check the license on the Kaggle page before reusing. Filtered to milk / shake related
reviews and sampled evenly across star ratings (TODO: n = ___).

## Method
1. `prepare_data.py`: filter, clean, and sample reviews.
2. `extract.py`: LLM returns JSON (sentiment, topics, complaint summary). Three prompt variants in `prompts.py`.
3. `evaluate.py`: sentiment scored against star ratings (1-2 negative, 3 neutral, 4-5 positive);
   topics scored against ___ reviews I labeled by hand; compared with a TF-IDF + logistic regression baseline.
4. `insights.py`: topic mention rates in positive vs. negative reviews.

## Results
TODO: paste the table printed by `evaluate.py` (also saved to `outputs/summary.csv`).

| Model | Sentiment accuracy | Sentiment macro-F1 | Topic micro-F1 |
|---|---|---|---|
| Prompt v1 (basic) | | | |
| Prompt v2 (definitions) | | | |
| Prompt v3 (few-shot) | | | |
| TF-IDF + LogReg baseline | | | n/a |

TODO: 3-4 sentences on what you found. Which prompt won, and by how much? Did the LLM beat the baseline?
Where did it fail? (Read `outputs/disagreements_*.csv` for error analysis.)

## Limitations (keep these honest)
- Star ratings are a noisy proxy for sentiment; many "errors" may be the label's fault. TODO: note examples you found.
- The sample is balanced by star rating, so sentiment shares do not describe the real customer base.
- Topic labels come from one annotator (me) on a small set.
- Reviews end in 2012 and are not specific to any one brand.

## Reproduce
```bash
pip install -r requirements.txt
export ANTHROPIC_API_KEY=...            # Windows PowerShell: $env:ANTHROPIC_API_KEY="..."
python prepare_data.py --input Reviews.csv --n 500
# hand-label data/topic_labels.csv
python extract.py --variant v1_basic --limit 5     # sanity check first
python extract.py --variant v1_basic
python extract.py --variant v2_definitions
python extract.py --variant v3_fewshot
python evaluate.py --full Reviews.csv
python insights.py --variant v3_fewshot            # use your best variant
```
`--dry-run` on `extract.py`, `evaluate.py`, and `insights.py` runs the whole pipeline with a
keyword heuristic instead of the API, to test your setup for free.

## Next steps (ideas)
- Track prompt experiments with MLflow.
- Add a RAG step to answer questions about the reviews.
- Show the insights in a Power BI or Streamlit dashboard.
